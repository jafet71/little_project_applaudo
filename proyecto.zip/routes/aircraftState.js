const express = require('express');
const router = express.Router();

const {
  getAllAircraftStates,
  getAircraftStateById,
  createAircraftState,
  updateAircraftState,
  deleteAircraftState
} = require('../controllers/AircraftStateController');

// Rutas
router.get('/aircraft-states', getAllAircraftStates);
router.get('/aircraft-states/:id', getAircraftStateById);
router.post('/aircraft-states', createAircraftState);
router.put('/aircraft-states/:id', updateAircraftState);
router.delete('/aircraft-states/:id', deleteAircraftState);

module.exports = router;
