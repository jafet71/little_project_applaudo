const express = require('express');
const router = express.Router();

const {
  getAllAircraft,
  getAircraftById,
  createAircraft,
  updateAircraft,
  deleteAircraft
} = require('../controllers/AircraftController');

// Rutas
router.get('/aircrafts', getAllAircraft);
router.get('/aircrafts/:id', getAircraftById);
router.post('/aircrafts', createAircraft);
router.put('/aircrafts/:id', updateAircraft);
router.delete('/aircrafts/:id', deleteAircraft);

module.exports = router;