const express = require('express');
const router = express.Router();

const {
  getAllAirlines,
  getAirlineById,
  createAirline,
  updateAirline,
  deleteAirline
} = require('../controllers/AirlineController');

// Rutas
router.get('/airlines', getAllAirlines);
router.get('/airlines/:id', getAirlineById);
router.post('/airlines', createAirline);
router.put('/airlines/:id', updateAirline);
router.delete('/airlines/:id', deleteAirline);

module.exports = router;
