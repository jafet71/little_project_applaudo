const express = require('express');
const router = express.Router();

const {
  getAllBoardingGates,
  getBoardingGateById,
  createBoardingGate,
  updateBoardingGate,
  deleteBoardingGate
} = require('../controllers/BoardingGateController');

// Rutas
router.get('/boarding-gates', getAllBoardingGates);
router.get('/boarding-gates/:id', getBoardingGateById);
router.post('/boarding-gates', createBoardingGate);
router.put('/boarding-gates/:id', updateBoardingGate);
router.delete('/boarding-gates/:id', deleteBoardingGate);

module.exports = router;
