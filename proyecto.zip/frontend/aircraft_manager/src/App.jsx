import './App.css'
import { Navbar } from './components/NavBar'

function App() {
  <div>
    <Navbar />
  </div>
}

export default App
