const Airline = require('../models/Airline');

// Obtener todas las aerolíneas
const getAllAirlines = async (req, res) => {
  try {
    const airlines = await Airline.findAll();
    console.log(airlines)
    res.json({
      success: true,
      data: airlines
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Obtener una aerolínea por ID
const getAirlineById = async (req, res) => {
  const { id } = req.params;

  try {
    const airline = await Airline.findByPk(id);
    if (!airline) {
      return res.status(404).json({
        success: false,
        error: 'Airline not found'
      });
    }
    res.json({
      success: true,
      data: airline
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Crear una nueva aerolínea
const createAirline = async (req, res) => {
  const { name, country } = req.body;

  try {
    const airline = await Airline.create({
      name,
      country
    });
    res.status(201).json({
      success: true,
      data: airline
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Actualizar una aerolínea por ID
const updateAirline = async (req, res) => {
  const { id } = req.params;
  const { name, country } = req.body;

  try {
    const airline = await Airline.findByPk(id);
    if (!airline) {
      return res.status(404).json({
        success: false,
        error: 'Airline not found'
      });
    }
    airline.name = name;
    airline.country = country;
    await airline.save();

    res.json({
      success: true,
      data: airline
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Eliminar una aerolínea por ID
const deleteAirline = async (req, res) => {
  const { id } = req.params;

  try {
    const airline = await Airline.findByPk(id);
    if (!airline) {
      return res.status(404).json({
        success: false,
        error: 'Airline not found'
      });
    }
    await airline.destroy();

    res.json({
      success: true,
      message: 'Airline deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

module.exports = {
  getAllAirlines,
  getAirlineById,
  createAirline,
  updateAirline,
  deleteAirline
};
