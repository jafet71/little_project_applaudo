const Aircraft = require('../models/Aircraft');

// Obtener todos los aviones
const getAllAircraft = async (req, res) => {
  try {
    const aircraft = await Aircraft.findAll();
    res.json({
      success: true,
      data: aircraft
    });
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Obtener un avión por ID
const getAircraftById = async (req, res) => {
  const { id } = req.params;

  try {
    const aircraft = await Aircraft.findByPk(id);
    if (!aircraft) {
      return res.status(404).json({
        success: false,
        error: 'Aircraft not found'
      });
    }
    res.json({
      success: true,
      data: aircraft
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Crear un nuevo avión
const createAircraft = async (req, res) => {
  const { registrationNumber, airline_id, passengerCapacity, state_id } = req.body;

  try {
    const aircraft = await Aircraft.create({
      registrationNumber,
      airline_id,
      passengerCapacity,
      state_id
    });
    res.status(201).json({
      success: true,
      data: aircraft
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Actualizar un avión por ID
const updateAircraft = async (req, res) => {
  const { id } = req.params;
  const { registrationNumber, airline_id, passengerCapacity, state_id } = req.body;

  try {
    const aircraft = await Aircraft.findByPk(id);
    if (!aircraft) {
      return res.status(404).json({
        success: false,
        error: 'Aircraft not found'
      });
    }
    aircraft.registrationNumber = registrationNumber;
    aircraft.airline_id = airline_id;
    aircraft.passengerCapacity = passengerCapacity;
    aircraft.state_id = state_id;
    await aircraft.save();

    res.json({
      success: true,
      data: aircraft
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Eliminar un avión por ID
const deleteAircraft = async (req, res) => {
  const { id } = req.params;

  try {
    const aircraft = await Aircraft.findByPk(id);
    if (!aircraft) {
      return res.status(404).json({
        success: false,
        error: 'Aircraft not found'
      });
    }
    aircraft.state_id = 'no disponible';
    await aircraft.save();

    res.json({
      success: true,
      message: 'Aircraft deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

module.exports = {
  getAllAircraft,
  getAircraftById,
  createAircraft,
  updateAircraft,
  deleteAircraft
};
