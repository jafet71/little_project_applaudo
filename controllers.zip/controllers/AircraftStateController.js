const AircraftState = require('../models/AircraftState');

// Obtener todos los estados de los aviones
const getAllAircraftStates = async (req, res) => {
  try {
    const aircraftStates = await AircraftState.findAll();
    res.json({
      success: true,
      data: aircraftStates
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Obtener un estado de avión por ID
const getAircraftStateById = async (req, res) => {
  const { id } = req.params;

  try {
    const aircraftState = await AircraftState.findByPk(id);
    if (!aircraftState) {
      return res.status(404).json({
        success: false,
        error: 'Aircraft State not found'
      });
    }
    res.json({
      success: true,
      data: aircraftState
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Crear un nuevo estado de avión
const createAircraftState = async (req, res) => {
  const { name } = req.body;

  try {
    const aircraftState = await AircraftState.create({
      name
    });
    res.status(201).json({
      success: true,
      data: aircraftState
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Actualizar un estado de avión por ID
const updateAircraftState = async (req, res) => {
  const { id } = req.params;
  const { name } = req.body;

  try {
    const aircraftState = await AircraftState.findByPk(id);
    if (!aircraftState) {
      return res.status(404).json({
        success: false,
        error: 'Aircraft State not found'
      });
    }
    aircraftState.name = name;
    await aircraftState.save();

    res.json({
      success: true,
      data: aircraftState
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Eliminar un estado de avión por ID
const deleteAircraftState = async (req, res) => {
  const { id } = req.params;

  try {
    const aircraftState = await AircraftState.findByPk(id);
    if (!aircraftState) {
      return res.status(404).json({
        success: false,
        error: 'Aircraft State not found'
      });
    }
    await aircraftState.destroy();

    res.json({
      success: true,
      message: 'Aircraft State deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

module.exports = {
  getAllAircraftStates,
  getAircraftStateById,
  createAircraftState,
  updateAircraftState,
  deleteAircraftState
};
