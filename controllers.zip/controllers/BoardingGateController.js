const BoardingGate = require('../models/BoardingGate');

// Obtener todos los Boarding Gates
const getAllBoardingGates = async (req, res) => {
  try {
    const boardingGates = await BoardingGate.findAll();
    res.json({
      success: true,
      data: boardingGates
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Obtener un Boarding Gate por ID
const getBoardingGateById = async (req, res) => {
  const { id } = req.params;

  try {
    const boardingGate = await BoardingGate.findByPk(id);
    if (!boardingGate) {
      return res.status(404).json({
        success: false,
        error: 'Boarding Gate not found'
      });
    }
    res.json({
      success: true,
      data: boardingGate
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Crear un nuevo Boarding Gate
const createBoardingGate = async (req, res) => {
  const { gateNumber, availability } = req.body;

  try {
    const boardingGate = await BoardingGate.create({
      gateNumber,
      availability
    });
    res.status(201).json({
      success: true,
      data: boardingGate
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Actualizar un Boarding Gate por ID
const updateBoardingGate = async (req, res) => {
  const { id } = req.params;
  const { gateNumber, availability } = req.body;

  try {
    const boardingGate = await BoardingGate.findByPk(id);
    if (!boardingGate) {
      return res.status(404).json({
        success: false,
        error: 'Boarding Gate not found'
      });
    }
    boardingGate.gateNumber = gateNumber;
    boardingGate.availability = availability;
    await boardingGate.save();

    res.json({
      success: true,
      data: boardingGate
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

// Eliminar un Boarding Gate por ID
const deleteBoardingGate = async (req, res) => {
  const { id } = req.params;

  try {
    const boardingGate = await BoardingGate.findByPk(id);
    if (!boardingGate) {
      return res.status(404).json({
        success: false,
        error: 'Boarding Gate not found'
      });
    }
    await boardingGate.destroy();

    res.json({
      success: true,
      message: 'Boarding Gate deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal Server Error'
    });
  }
};

module.exports = {
  getAllBoardingGates,
  getBoardingGateById,
  createBoardingGate,
  updateBoardingGate,
  deleteBoardingGate
};
